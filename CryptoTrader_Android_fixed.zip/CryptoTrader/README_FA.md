# Crypto Trader Android

نسخه اصلاح‌شده پروژه اندروید است. مشکل کامپایل نسخه قبلی برطرف شده است.

ویژگی‌ها:
- دریافت جفت‌های USDT قابل معامله از Binance
- قیمت و نمودار 15 دقیقه‌ای
- RSI(14)، EMA20 و MACD
- جستجوی ارزها
- واچ‌لیست
- Paper Trading محلی (بدون سفارش واقعی)

برای ساخت APK: پروژه را در Android Studio باز کنید و `app` را Build کنید.
یا workflow موجود در `.github/workflows/build.yml` را در GitHub اجرا کنید.
